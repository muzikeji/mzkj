
var cookies = {CookieJD1:'pt_key=AAJhI0l_ADCYubZNa1cY6erfjumsAksftMwXLfSfZcTnbvAbgN_FvDjaonmxSISPzjbXYuKuH80;pt_pin=jd_ZoZwKlIVWjhF;',CookieJD2:'pt_key=;pt_pin=jd_QfYQtLeMUEfM;',CookieJD3:'pt_key=AAJhINk8ADDCpwSBpRT2IoCP446fkxuIzESkck0T7BEjjRFYU_rb9fCJ46UuSgOuVae5BaHOrI8;pt_pin=jd_75fd850b2633e;',CookieJD4:'pt_key=AAJhITFUADD6AHOs2nCFSVKB2n_oiuOVjuPQHjTm9vylaSPoCazhIPPQ21s_JWueNV1HNmQ6zm8;pt_pin=jd_40190de02dae8;',CookieJD5:'pt_key=AAJhINHYADAKK6sELinkyiu9iTM8g0CNEbRaD1jowrJYnyxWYZmQJ7xSjbp_wN31BFsbjELv1kQ;pt_pin=jd_VxfUVWFGLyTZ;',CookieJD6:'pt_key=AAJhITQrADCH6tdfEhisLZcv7bJ-PY25UPfwM_BVfHx_MgAsE2p_-N0S-eWubAwIlhXKuwyUr4k;pt_pin=jd_4219cb15b920f;',CookieJD7:'pt_key=;pt_pin=jd_57678cfcb1858;',CookieJD8:'pt_key=AAJhITIAADD8LGIrraJG7uMJp7C0zQxZDWnhtUdAYbIw1vPaGmI30K3sJxeAY3buP-dmJ5w5l3o;pt_pin=jd_DDViNKlVQEkR;',CookieJD9:'pt_key=AAJhF16PADA8k0nokFADHXtzXam9CjCQSbHNpgeGXnXS_x8Yh520IVBaBvKdMdbFN_pYodzhIAQ;pt_pin=jd_56cc3dd665427;',CookieJD10:'pt_key=;pt_pin=jd_4f0e4448956a1;',CookieJD11:'pt_key=;pt_pin=wdezewRmzadfyE;',CookieJD12:'pt_key=;pt_pin=26076402-144632;',CookieJD13:'pt_key=AAJhKJpnADCALKX0DvUKwbv_h0BeyQk2cZ2vaH2t5V-AA6ot8cTBOmGUvO0kll__gUh_xjlUeW0;pt_pin=jd_5ba23fa874bf7;'}
var pins = process.env.pins
if(pins){
	pins = pins.split("&")
	for (var key in cookies) {
	    c = false
	    for (var pin of pins) {
		   if (pin && cookies[key].indexOf(pin) != -1) {
			  c = true
			  break
		   }
	    }
	    if (!c) {
		   delete cookies[key]
	    }
	}
}
module.exports = cookies