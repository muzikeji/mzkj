return reply(
     [
          `早上好`=>`good morning`
          `壁纸` => `https://acg.toubiec.cn/random.php`
     ]
)