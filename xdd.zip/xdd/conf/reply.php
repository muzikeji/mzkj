return reply(
     [
          `早上好`=>`good morning`
          `下一个` => `https://acg.toubiec.cn/random.php`
          `你好`=> `好个锤子`
          `许愿` => `输入"许愿 任意内容"`
          `姐姐` => `太色了，暂不开放`
          `妹妹` => `https://laosepi.org/pic.php`
          `壁纸` => `http://api.btstu.cn/sjbz/?lx=dongman`
          `风景` => `https://laosepi.org/gqpic.php`
          `美女` => `https://api.lyiqk.cn/purelady`
         `二次元图` => `https://acg.toubiec.cn/random.php`
         `网易热评` => `https://api.uomg.com/api/comments.163?format=json`
         `动漫头像` => `http://shengapi.cn/api/image/acgtx.php`
         `舔狗日记` => `http://shengapi.cn/api/tgrj.php`
         `.*骚话.*`=>`https://api.vvhan.com/api/sao`
         `文明` => `http://api.btstu.cn/sjbz/zsy.php`
          `富强` => `http://api.btstu.cn/sjbz/?m_lx=suiji`
          `和谐` => `http://api.btstu.cn/sjbz/zsy.php`
          `民主` => `http://api.nmb.show/xiaojiejie2.php`
          `语录` => `https://api.ixiaowai.cn/ylapi/index.php`
          `舔狗` => `https://api.ixiaowai.cn/tgrj/index.php`
          `.*一言.*`=>`https://api.ixiaowai.cn/ylapi/index.php`
        `更新` => `发送扫码或进入网站绑定QQ`
        `公告` => `发送扫码绑定QQ后输入"查询"`
        `密码` => `1878119794`
        `菜单` => `
                京东菜单
       ———————————     
            更新  丨  查询       
            公告  丨  扫码
       ———————————             
                娱乐菜单
       ———————————    
            富强  丨 民主
            文明  丨 和谐
            妹妹  丨 美女       
            风景  丨 壁纸       
            你好  丨 姐姐       
            状态  丨 许愿
            骚话  丨 一言
       二次元图丨 网易热评 
       动漫头像丨 舔狗日记       
      ———————————         
              京东机器人
              
              更新地址:
     http://47.106.187.163:8080 `       
        ] )